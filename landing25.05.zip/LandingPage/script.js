document.addEventListener('DOMContentLoaded', function() {
    const ctaFinal = document.getElementById('ctaFinal');

    ctaFinal.addEventListener('mouseup', function() {
        mostrarMensaje();
    });

    function mostrarMensaje() {
        const form = document.querySelector('.form');
        const nombreUsuario = form.querySelector('input[name="input-name"]').value;
        const correoUsuario = form.querySelector('input[name="input-email"]').value;
        if (nombreUsuario && correoUsuario) {
            const mensaje = `¡Gracias ${nombreUsuario} por inscribirte, te enviaremos a ${correoUsuario} tu calendario personalizado!`;
            alert(mensaje);
        } else {
            alert('Por favor, ingresa tu nombre y tu correo electrónico.');
        }
    }
});
